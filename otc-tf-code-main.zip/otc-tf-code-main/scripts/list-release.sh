#!/bin/bash

# Set your GitLab variables
GITLAB_URL="https://gitlab.devops.telekom.de/"
PROJECT_ID="226743"
#ACCESS_TOKEN=""

# Get a list of releases
RELEASES=$(curl --header "PRIVATE-TOKEN: $ACCESS_TOKEN" "$GITLAB_URL/api/v4/projects/$PROJECT_ID/releases")

# Parse the release names and versions
RELEASE_NAMES=($(echo $RELEASES | jq -r '.[].name'))
RELEASE_VERSIONS=($(echo $RELEASES | jq -r '.[].tag_name'))

# Display the list of releases
echo "Available Releases:"
for i in "${!RELEASE_NAMES[@]}"
do
    echo "$(($i+1)). ${RELEASE_NAMES[$i]} (Version: ${RELEASE_VERSIONS[$i]})"
done

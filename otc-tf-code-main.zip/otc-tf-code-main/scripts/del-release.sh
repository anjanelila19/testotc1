#!/bin/bash

# Set your GitLab variables
PROJECT_ID="226743"
RELEASE_VERSION="v1.1.137"
#ACCESS_TOKEN=""

# Define the GitLab API endpoint for releases
RELEASES_API="https://gitlab.devops.telekom.de/api/v4/projects/${PROJECT_ID}/releases/${RELEASE_VERSION}"

# Send the DELETE request
curl --request DELETE --header "PRIVATE-TOKEN: ${PRIVATE_TOKEN}" "${RELEASES_API}"

import os
import boto3
from urllib.request import urlretrieve
import urllib3

urllib3.disable_warnings()

# Retrieve access key and secret key from environment variables
access_key = os.environ.get('OBS_ACCESS_KEY')
secret_key = os.environ.get('OBS_SECRET_KEY')
bucket_name = os.environ.get('OBS_BUCKET_NAME')
object_name = os.environ.get('OBS_OBJECT_NAME')

# Initialize OBS client with retrieved credentials
client = boto3.client('s3',
                      endpoint_url='https://obs.otc.t-systems.com',
                      aws_access_key_id=access_key,
                      aws_secret_access_key=secret_key,
                      region_name='eu-de',
                      verify=False)  # Set to False if SSL certificate verification is not required

# Put an object
client.put_object(Bucket=bucket_name, Key=object_name, Body='OBS Bucket Content!')

# Get an object
response = client.get_object(Bucket=bucket_name, Key=object_name)
content = response['Body'].read().decode('utf-8')
print(f'Contents of {object_name}: {content}')

# List objects in a bucket
response = client.list_objects(Bucket=bucket_name)
for obj in response['Contents']:
    print(f'Object: {obj["Key"]}, Size: {obj["Size"]} bytes')

# Delete an object
# client.delete_object(Bucket=bucket_name, Key=object_name)

# Follow below steps to run script
# pip install boto3
# export OBS_ACCESS_KEY='<replace-me>'
# export OBS_SECRET_KEY='<replace-me>'
# export OBS_BUCKET_NAME='<replace-me>'
# export OBS_OBJECT_NAME='<repalce-me>'
# python3 obs-manage.py 

## IaC using terraform for OTC

This repo contains IaC for OTC


### terraform/tf-backend

Terraform code for creating a terraform state backend

### terraform/modules

Terraform modules for VPC, ECS and CCE

### terraform/examples

Examples of calling modules and creating VPC, ECS and CCE

## How to use

```
git clone https://gitlab.devops.telekom.de/ai/genai/otc-tf-code.git
cd terraform/examples/infra
export OS_ACCESS_KEY="<replace-me>"      
export OS_SECRET_KEY="<replace-me>"      
export AWS_ACCESS_KEY_ID=$OS_ACCESS_KEY
export AWS_SECRET_ACCESS_KEY=$OS_SECRET_KEY
terraform init
terrafrom plan
terraform apply

```


## Authors

- [@prayag.sangode](https://gitlab.devops.telekom.de/prayag.sangode)


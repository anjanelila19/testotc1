## Create terraform backend to store remote terraform state 

This section contains code for creating terraform backend to store remote terraform state

## Usage
Set your AK/SK and source

```
cd existing_repo
git remote add origin https://gitlab.devops.telekom.de/ai/genai/tf-hub-otc-vllm.git
cd tf-hub-otc-vllm/tf-backend
export OS_ACCESS_KEY="<replace-me>"      # Access Key ID 
export OS_SECRET_KEY="<replace-me>"      # Secret Access Key 
export OS_DOMAIN_NAME="<replace-me"      # OTC domain for the project 
export TF_VAR_bucket_name="<replace-me"  # Bucket name to store terraform state 
export AWS_ACCESS_KEY_ID=$OS_ACCESS_KEY
export AWS_SECRET_ACCESS_KEY=$OS_SECRET_KEY
terraform init
terraform plan
terraform apply
```

## Authors

- [@prayag.sangode](https://gitlab.devops.telekom.de/prayag.sangode)

